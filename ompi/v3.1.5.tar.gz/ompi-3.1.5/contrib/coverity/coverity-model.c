void opal_btl_usnic_util_abort(const char *msg, const char *file, int line) {
    __coverity_panic__();
}
